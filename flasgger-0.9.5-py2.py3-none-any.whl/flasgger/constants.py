OPTIONAL_FIELDS = [
    'tags', 'consumes', 'produces', 'schemes', 'security',
    'deprecated', 'operationId', 'externalDocs'
]

OPTIONAL_OAS3_FIELDS = [
    'components', 'servers'
]
