.. seealso::
  Need help upgrading to a newer version? Check out the :doc:`upgrading guide <upgrading>`.

.. include:: ../CHANGELOG.rst
